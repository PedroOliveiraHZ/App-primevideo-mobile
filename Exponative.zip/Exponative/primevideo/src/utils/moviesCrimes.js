export const MOVIESCRIME = [
  {
    id: "1",
    name: "Dark Knight",
    moviesURL: require("../assets/movies/dark-knight.png"),
  },
  {
    id: "2",
    name: "Sherlock Holmes",
    moviesURL: require("../assets/movies/sherlock_holmes.png"),
  },
  {
    id: "3",
    name: "Dark Knight",
    moviesURL: require("../assets/movies/dark-knight.png"),
  },
];
